# URBAN LEGENDS — Next Gen (Playable Prototype)

A browser-based, procedural 3D open-world exploration prototype set in Vice City North.

## Run it

1. Install Node.js 20+.
2. Extract this folder.
3. Open a terminal in this folder.
4. Run:

```bash
npm install
npm run dev
```

5. Open the local URL printed by Vite (usually http://localhost:5173).

For a production build, run `npm run build`.

## Controls

- **W / A / S / D** — walk or drive
- **Shift** — sprint on foot
- **Space** — jump on foot / handbrake in vehicle
- **F** or **E** — enter/exit the red sports coupe (stand close to it)
- **M** — open/close map panel
- **V** — toggle camera perspective
- **Esc** — pause/resume

## Included in this first playable build

- Procedurally generated 3D city grid, buildings, roads, sidewalks-like street blocks, waterfront, beach and trees
- Third-person character movement, sprinting and jumping
- Drivable sports coupe with acceleration, reverse, steering, wheel rotation and chase camera
- Moving ambient traffic and pedestrian NPCs
- HUD, mission prompt, speed readout, map overview, pause panel and local save
- Day clock display and a simple clear/rain UI toggle
- Responsive interface and graphics tuned for ordinary desktop hardware

## Scope notes

This is an honest first playable prototype, not a finished AAA game. The city is procedural geometry and the traffic/pedestrian behaviors are lightweight ambient simulation. Advanced systems such as detailed interiors, full story campaign, sophisticated navigation/traffic rules, multiplayer, voice acting, realistic vehicle damage, and production-quality character/vehicle assets are not implemented yet. The weather toggle currently changes the HUD state only; full rain rendering is a future milestone.

## Project structure

- `src/Game.jsx` — game scene, input, movement, vehicle, NPC simulation and HUD
- `src/style.css` — interface and responsive styling
- `src/main.jsx` — React entry point
