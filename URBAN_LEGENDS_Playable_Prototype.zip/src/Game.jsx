import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { Map, CarFront, Footprints, Sun, CloudRain, Pause, Play, RotateCcw, Volume2, VolumeX } from 'lucide-react';

const clamp=(v,a,b)=>Math.max(a,Math.min(b,v));
const rand=(a,b)=>a+Math.random()*(b-a);

function makeCity(scene){
  const ground=new THREE.Mesh(new THREE.PlaneGeometry(900,900),new THREE.MeshStandardMaterial({color:0x263b3a,roughness:1}));
  ground.rotation.x=-Math.PI/2; ground.position.y=-.08; ground.receiveShadow=true; scene.add(ground);
  const roadMat=new THREE.MeshStandardMaterial({color:0x202832,roughness:.94});
  const lineMat=new THREE.MeshStandardMaterial({color:0xe4d8a6,roughness:.8});
  // Road grid, sidewalks and lane markings.
  for(let i=-5;i<=5;i++){
    const z=i*42, x=i*42;
    const road1=new THREE.Mesh(new THREE.PlaneGeometry(900,13),roadMat); road1.rotation.x=-Math.PI/2; road1.position.set(0,.005,z); scene.add(road1);
    const road2=new THREE.Mesh(new THREE.PlaneGeometry(13,900),roadMat); road2.rotation.x=-Math.PI/2; road2.position.set(x,.006,0); scene.add(road2);
    for(let k=-10;k<=10;k++){
      const dash=new THREE.Mesh(new THREE.PlaneGeometry(3,.16),lineMat); dash.rotation.x=-Math.PI/2; dash.position.set(k*38,.02,z); scene.add(dash);
      const dash2=new THREE.Mesh(new THREE.PlaneGeometry(.16,3),lineMat); dash2.rotation.x=-Math.PI/2; dash2.position.set(x,.02,k*38); scene.add(dash2);
    }
  }
  const buildingMats=[0x526575,0x6d7880,0x8c8174,0x344b5c,0x786f70,0x465c65].map(c=>new THREE.MeshStandardMaterial({color:c,roughness:.72,metalness:.12}));
  const windowMat=new THREE.MeshStandardMaterial({color:0x8fc7d5,emissive:0x183744,roughness:.25,metalness:.45});
  for(let gx=-10;gx<=10;gx++) for(let gz=-10;gz<=10;gz++){
    if(Math.abs(gx)%1===0 && (Math.abs(gx*42)%42<2 || Math.abs(gz*42)%42<2)) continue;
    const cx=gx*42+rand(-9,9), cz=gz*42+rand(-9,9);
    if(Math.abs(cx%42)<10 || Math.abs(cz%42)<10) continue;
    const w=rand(11,22), d=rand(11,22), h=rand(12,75);
    const b=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),buildingMats[Math.floor(Math.random()*buildingMats.length)]);
    b.position.set(cx,h/2,cz); b.castShadow=true; b.receiveShadow=true; scene.add(b);
    // Repeated glowing window bands make buildings legible from street level.
    for(let y=4;y<h-2;y+=4){
      const strip=new THREE.Mesh(new THREE.BoxGeometry(w+.04,.45,d+.04),windowMat);
      strip.position.set(cx,y,cz); scene.add(strip);
    }
    const roof=new THREE.Mesh(new THREE.BoxGeometry(w*.28,1,d*.28),buildingMats[1]); roof.position.set(cx,h+.5,cz); scene.add(roof);
  }
  // Waterfront and beach on the eastern edge.
  const water=new THREE.Mesh(new THREE.PlaneGeometry(240,900),new THREE.MeshStandardMaterial({color:0x147c9a,metalness:.35,roughness:.2}));
  water.rotation.x=-Math.PI/2; water.position.set(430,-.12,0); scene.add(water);
  const sand=new THREE.Mesh(new THREE.PlaneGeometry(55,900),new THREE.MeshStandardMaterial({color:0xc6ae7b,roughness:1}));
  sand.rotation.x=-Math.PI/2; sand.position.set(300,-.04,0); scene.add(sand);
  // Parks and trees.
  const trunkMat=new THREE.MeshStandardMaterial({color:0x59402d}), leafMat=new THREE.MeshStandardMaterial({color:0x2e7650,roughness:1});
  for(let i=0;i<90;i++){
    const x=rand(-390,390),z=rand(-390,390);
    if(Math.abs(x%42)<10||Math.abs(z%42)<10||x>280) continue;
    const trunk=new THREE.Mesh(new THREE.CylinderGeometry(.25,.38,3,7),trunkMat); trunk.position.set(x,1.5,z); scene.add(trunk);
    const crown=new THREE.Mesh(new THREE.SphereGeometry(rand(1.6,2.8),8,7),leafMat); crown.position.set(x,4,z); crown.castShadow=true; scene.add(crown);
  }
  // Landmark sign and gas station canopy.
  const sign=new THREE.Mesh(new THREE.BoxGeometry(14,4,.5),new THREE.MeshStandardMaterial({color:0x101c2a,emissive:0x173c57}));
  sign.position.set(0,12,-92); scene.add(sign);
  const station=new THREE.Mesh(new THREE.BoxGeometry(18,1,13),new THREE.MeshStandardMaterial({color:0xe5e9eb})); station.position.set(-75,5,-85); scene.add(station);
  return {water};
}

function makeCar(scene,color=0xe14d35){
  const group=new THREE.Group();
  const paint=new THREE.MeshStandardMaterial({color,metalness:.72,roughness:.24});
  const glass=new THREE.MeshStandardMaterial({color:0x172d3a,metalness:.45,roughness:.15});
  const body=new THREE.Mesh(new THREE.BoxGeometry(2.2,.72,4.4),paint); body.position.y=.75; body.castShadow=true; group.add(body);
  const cabin=new THREE.Mesh(new THREE.BoxGeometry(1.72,.78,2.05),glass); cabin.position.set(0,1.42,-.25); cabin.castShadow=true; group.add(cabin);
  const bumperMat=new THREE.MeshStandardMaterial({color:0x171c22,metalness:.4});
  for(const z of [-2.18,2.18]){const bumper=new THREE.Mesh(new THREE.BoxGeometry(2.12,.2,.16),bumperMat);bumper.position.set(0,.56,z);group.add(bumper);}
  const wheelGeo=new THREE.CylinderGeometry(.43,.43,.28,16), wheelMat=new THREE.MeshStandardMaterial({color:0x101215,roughness:.9});
  const wheels=[];
  for(const x of [-1.12,1.12]) for(const z of [-1.35,1.35]){
    const wheel=new THREE.Mesh(wheelGeo,wheelMat); wheel.rotation.z=Math.PI/2; wheel.position.set(x,.45,z); group.add(wheel); wheels.push(wheel);
  }
  const lightMat=new THREE.MeshStandardMaterial({color:0xfff1c9,emissive:0x66502a});
  for(const x of [-.72,.72]){const light=new THREE.Mesh(new THREE.BoxGeometry(.42,.2,.08),lightMat);light.position.set(x,.86,2.22);group.add(light);}
  group.userData.wheels=wheels; group.userData.speed=0; return group;
}

function makePerson(scene,color=0xd7a46b){
  const g=new THREE.Group();
  const mat=new THREE.MeshStandardMaterial({color,roughness:.9});
  const torso=new THREE.Mesh(new THREE.CapsuleGeometry(.36,.65,4,8),mat);torso.position.y=1.15;g.add(torso);
  const head=new THREE.Mesh(new THREE.SphereGeometry(.27,12,10),new THREE.MeshStandardMaterial({color:0xc58c68}));head.position.y=1.85;g.add(head);
  return g;
}

export default function Game(){
  const mount=useRef(null), api=useRef(null);
  const [started,setStarted]=useState(false),[paused,setPaused]=useState(false),[inCar,setInCar]=useState(false),[speed,setSpeed]=useState(0),[time,setTime]=useState('09:42'),[weather,setWeather]=useState('CLEAR'),[mission,setMission]=useState('Explore Vice City North'),[notice,setNotice]=useState('Welcome to Vice City North'),[muted,setMuted]=useState(true),[mapOpen,setMapOpen]=useState(false),[firstPerson,setFirstPerson]=useState(false);
  useEffect(()=>{
    const host=mount.current; if(!host) return;
    const scene=new THREE.Scene(); scene.background=new THREE.Color(0x8bb7ca); scene.fog=new THREE.Fog(0x8bb7ca,100,520);
    const camera=new THREE.PerspectiveCamera(65,host.clientWidth/host.clientHeight,.1,1200);
    const renderer=new THREE.WebGLRenderer({antialias:true,powerPreference:'high-performance'});
    renderer.setSize(host.clientWidth,host.clientHeight); renderer.setPixelRatio(Math.min(devicePixelRatio,1.7)); renderer.shadowMap.enabled=true; renderer.shadowMap.type=THREE.PCFSoftShadowMap; renderer.toneMapping=THREE.ACESFilmicToneMapping; renderer.toneMappingExposure=1.12; host.appendChild(renderer.domElement);
    const hemi=new THREE.HemisphereLight(0xcdeaff,0x35402f,2.1);scene.add(hemi);
    const sun=new THREE.DirectionalLight(0xffe0b4,2.6);sun.position.set(-100,160,80);sun.castShadow=true;sun.shadow.mapSize.set(2048,2048);sun.shadow.camera.left=-180;sun.shadow.camera.right=180;sun.shadow.camera.top=180;sun.shadow.camera.bottom=-180;scene.add(sun);
    makeCity(scene);
    const player=new THREE.Group(); const body=makePerson(scene,0x345d89); player.add(body); player.position.set(0,0,0);scene.add(player);
    const car=makeCar(scene,0xe34e37);car.position.set(9,0,4);scene.add(car);
    const traffic=[]; for(let i=0;i<14;i++){const c=makeCar(scene,[0x293d56,0xd4d1c8,0x337f77,0xb58a42][i%4]);c.scale.setScalar(.78);c.position.set(-220+i*32,0,42*(i%2?1:-1)+rand(-2,2));c.rotation.y=i%2?0:Math.PI;scene.add(c);traffic.push(c);}
    const peds=[];for(let i=0;i<22;i++){const p=makePerson(scene,[0xc27b50,0x487e70,0x9a739e,0xc9b68c][i%4]);p.position.set(rand(-240,240),0,rand(-240,240));scene.add(p);peds.push({mesh:p,phase:rand(0,6)});}
    const keys={};let driving=false,heading=0,velocity=0,clock=0,weatherMode=0;
    const down=e=>{keys[e.code]=true;if(['Space','ArrowUp','ArrowDown','ArrowLeft','ArrowRight'].includes(e.code))e.preventDefault();};
    const up=e=>{keys[e.code]=false;};
    window.addEventListener('keydown',down);window.addEventListener('keyup',up);
    const interact=()=>{if(driving){driving=false;player.position.copy(car.position);player.position.x+=3;setInCar(false);setNotice('You exited the vehicle');}else if(player.position.distanceTo(car.position)<8){driving=true;setInCar(true);setNotice('Vehicle acquired — drive safely');}else{setNotice('Nothing nearby to interact with');}};
    const keyAction=e=>{if(e.code==='KeyF'||e.code==='KeyE')interact();if(e.code==='KeyM')setMapOpen(v=>!v);if(e.code==='Escape')setPaused(v=>!v);if(e.code==='KeyV')setFirstPerson(v=>!v);};
    window.addEventListener('keydown',keyAction);
    const rayGround=new THREE.Plane(new THREE.Vector3(0,1,0),0);
    const loop=()=>{
      api.current?.raf && cancelAnimationFrame(api.current.raf);
      const animate=()=>{
        api.current.raf=requestAnimationFrame(animate); if(paused){renderer.render(scene,camera);return;}
        const dt=Math.min(clock?((performance.now()-clock)/1000):.016,.04);clock=performance.now();
        const forward=new THREE.Vector3(Math.sin(heading),0,Math.cos(heading));
        if(driving){
          const accel=(keys.KeyW||keys.ArrowUp?26:0)-(keys.KeyS||keys.ArrowDown?34:0);
          velocity+=accel*dt;velocity*=Math.pow(keys.Space?.91:.985,dt*60);velocity=clamp(velocity,-15,48);
          if(Math.abs(velocity)>.3)heading+=(keys.KeyA||keys.ArrowLeft?1:0)-(keys.KeyD||keys.ArrowRight?1:0)*0; 
          const steer=(keys.KeyA||keys.ArrowLeft?-1:0)+(keys.KeyD||keys.ArrowRight?1:0);
          heading+=steer*dt*(.65+Math.abs(velocity)*.025)*Math.sign(velocity||1);
          car.position.addScaledVector(new THREE.Vector3(Math.sin(heading),0,Math.cos(heading)),velocity*dt);car.rotation.y=heading;
          car.position.x=clamp(car.position.x,-420,420);car.position.z=clamp(car.position.z,-420,420);
          car.userData.wheels.forEach(w=>w.rotation.x+=velocity*dt*1.6);
          player.position.copy(car.position);
          setSpeed(Math.round(Math.abs(velocity)*3.6));
        }else{
          const move=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0);
          const strafe=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0);
          const sprint=keys.ShiftLeft||keys.ShiftRight?1.75:1;
          const dir=new THREE.Vector3(strafe,0,move);
          if(dir.lengthSq()>0){dir.normalize().applyAxisAngle(new THREE.Vector3(0,1,0),heading);player.position.addScaledVector(dir,dt*8*sprint);heading=Math.atan2(dir.x,dir.z);}
          if(keys.Space&&player.position.y<.05)player.userData.jump=5.5;
          player.userData.jump??=0;if(player.position.y>.02||player.userData.jump>0){player.userData.jump-=18*dt;player.position.y=Math.max(0,player.position.y+player.userData.jump*dt);if(player.position.y===0)player.userData.jump=0;}
          player.position.x=clamp(player.position.x,-420,420);player.position.z=clamp(player.position.z,-420,420);
          player.rotation.y=heading;setSpeed(0);
        }
        traffic.forEach((c,i)=>{c.position.x+=((i%2)?1:-1)*dt*(8+i%4);if(c.position.x>420)c.position.x=-420;if(c.position.x<-420)c.position.x=420;c.userData.wheels.forEach(w=>w.rotation.x+=dt*3);});
        peds.forEach(p=>{p.phase+=dt*.45;p.mesh.position.x+=Math.sin(p.phase)*dt*1.8;p.mesh.position.z+=Math.cos(p.phase*.7)*dt*1.2;p.mesh.rotation.y=Math.atan2(Math.sin(p.phase),Math.cos(p.phase*.7));});
        const target=driving?car.position:player.position;
        const camOffset=driving?(firstPerson?new THREE.Vector3(0,2.2,-.4):new THREE.Vector3(0,7,-13)):(firstPerson?new THREE.Vector3(0,1.6,0):new THREE.Vector3(0,6,-10));
        const rotated=camOffset.clone().applyAxisAngle(new THREE.Vector3(0,1,0),heading);
        const desired=target.clone().add(rotated);camera.position.lerp(desired,.11);camera.lookAt(target.x,target.y+(driving?1.2:1.4),target.z);
        renderer.render(scene,camera);
      };animate();
    };
    loop();
    const resize=()=>{camera.aspect=host.clientWidth/host.clientHeight;camera.updateProjectionMatrix();renderer.setSize(host.clientWidth,host.clientHeight);};
    window.addEventListener('resize',resize);
    api.current={scene,renderer,raf:null};
    return ()=>{window.removeEventListener('keydown',down);window.removeEventListener('keyup',up);window.removeEventListener('keydown',keyAction);window.removeEventListener('resize',resize);if(api.current?.raf)cancelAnimationFrame(api.current.raf);renderer.dispose();host.removeChild(renderer.domElement);};
  },[paused,firstPerson]);
  useEffect(()=>{const saved=localStorage.getItem('urban-legends-save');if(saved){try{const s=JSON.parse(saved);setMission(s.mission||'Explore Vice City North');}catch{}}},[]);
  useEffect(()=>{const id=setInterval(()=>{setTime(t=>{const [h,m]=t.split(':').map(Number);const n=(h*60+m+1)%1440;return `${String(Math.floor(n/60)).padStart(2,'0')}:${String(n%60).padStart(2,'0')}`;});},1500);return()=>clearInterval(id);},[]);
  const save=()=>{localStorage.setItem('urban-legends-save',JSON.stringify({mission,time}));setNotice('Progress saved locally');};
  const start=()=>{setStarted(true);setNotice('Welcome back, driver. The city is yours.');};
  return <main className="game-shell">
    <div className="game-world" ref={mount}/>
    {!started&&<div className="intro"><div className="brand"><span>UL</span><div><small>VICE CITY NORTH PRESENTS</small><h1>URBAN <i>LEGENDS</i></h1></div></div><p>THE CITY NEVER SLEEPS. YOUR STORY STARTS NOW.</p><button className="primary" onClick={start}><Play size={17} fill="currentColor"/> ENTER THE CITY</button><div className="intro-foot">OPEN WORLD • FREE ROAM • BUILD 0.1</div></div>}
    {started&&<>
      <header className="topbar"><div className="mini-brand"><b>UL</b><span>URBAN LEGENDS <small>VICE CITY NORTH</small></span></div><div className="top-right"><span className="live-dot"/> FREE ROAM <span className="sep"/> {time} <span className="sep"/> {weather}</div></header>
      <section className="mission"><small>CURRENT OBJECTIVE</small><strong>{mission}</strong><span>Explore the city and find your next opportunity.</span></section>
      <div className="status"><div><small>PLAYER STATUS</small><b><Footprints size={15}/> ON FOOT</b></div><div className="health"><small>VITALITY</small><span><i/></span>100%</div></div>
      {inCar&&<div className="speedo"><small>VEHICLE SPEED</small><strong>{speed}<em> KM/H</em></strong><div className="speedbar"><i style={{width:`${Math.min(100,speed/1.8)}%`}}/></div><small>SPORT COUPE · V8</small></div>}
      <div className="notice">{notice}</div>
      {mapOpen&&<div className="map-panel"><div className="map-head"><b>VICE CITY NORTH</b><button onClick={()=>setMapOpen(false)}>×</button></div><div className="map-art"><div className="map-road r1"/><div className="map-road r2"/><div className="map-road r3"/><div className="map-water"/><span className="map-pin">◆ YOU</span><span className="map-label">DOWNTOWN</span><span className="map-label beach">COASTLINE</span></div><small>MAP OVERVIEW · WAYPOINTS COMING IN A FUTURE BUILD</small></div>}
      <div className="controls"><div className="control-title">FIELD CONTROLS</div><div><kbd>W</kbd><kbd>A</kbd><kbd>S</kbd><kbd>D</kbd><span>MOVE / DRIVE</span></div><div><kbd>SHIFT</kbd><span>SPRINT</span><kbd>SPACE</kbd><span>JUMP / HANDBRAKE</span></div><div><kbd>F</kbd><span>ENTER / EXIT VEHICLE</span><kbd>E</kbd><span>INTERACT</span></div><div><kbd>M</kbd><span>MAP</span><kbd>V</kbd><span>CAMERA</span><kbd>ESC</kbd><span>PAUSE</span></div></div>
      <div className="actions"><button onClick={()=>setMapOpen(v=>!v)} title="Map"><Map/></button><button onClick={()=>setFirstPerson(v=>!v)} title="Camera"><RotateCcw/></button><button onClick={()=>setWeather(w=>w==='CLEAR'?'RAIN':'CLEAR')} title="Weather">{weather==='CLEAR'?<Sun/>:<CloudRain/>}</button><button onClick={()=>setMuted(v=>!v)} title="Audio">{muted?<VolumeX/>:<Volume2/>}</button><button onClick={save} title="Save">SAVE</button><button onClick={()=>setPaused(v=>!v)} title="Pause">{paused?<Play/>:<Pause/>}</button></div>
      {paused&&<div className="pause-overlay"><div><small>GAME PAUSED</small><h2>TAKE A BREATHER.</h2><button className="primary" onClick={()=>setPaused(false)}><Play size={16}/> RESUME GAME</button><button className="secondary" onClick={save}>SAVE PROGRESS</button></div></div>}
      <div className="crosshair">+</div>
      <div className="bottom-left"><span className="district-dot"/> DOWNTOWN / VICE CITY NORTH</div>
      <div className="interact-hint">APPROACH THE RED COUPE · PRESS <kbd>F</kbd> TO DRIVE</div>
    </>}
  </main>;
}
